<!-- Blog Page -->
<div class="blog-page">

	<!-- Page Title Section -->
	<section class="page-title-section fill-off-dark">
		<div class="container">
			<div class="row">
				<!-- Page Title -->
				<h1 class="h1 page-title columns small-12 medium-8 large-7 large-offset-1">
					Weekly Podcast
				</h1>
			</div>
		</div>
	</section>

	<!-- Featured Section -->
	<section class="featured-section fill-off-dark">
		<div class="container">
			<div class="row">

				<!-- Featured -->
				<div class="featured columns small-12 medium-8 large-7 large-offset-1">

					<div class="section-label h5 text-neutral">Featured</div>

					<!-- Post Featured Image -->
					<div class="post-featured-image">
						<img src="/img/thumb-ep-1.png">
					</div><!-- END : Post Featured Image -->

					<!-- Post Title -->
					<div class="post-title">
						<a href="#">
							<div class="h3">This is the Post Title</div>
						</a>
					</div><!-- END : Post Title -->

					<!-- Post Title Meta -->
					<div class="post-title-meta">
						<div class="h5 inline" href="">[podcast-icon]</div>
						<div class="h5 inline" href="">17 September 2017</div>
					</div><!-- END : Post Title Meta -->

					<!-- Post Content -->
					<div class="post-description h4">
						<h2>Pen Kowloon network futurity boat receding 3D-printed tattoo vehicle courier.</h2>

						<p>Corrupted sub-orbital kanji tank-traps garage bridge girl franchise savant 3D-printed systema systemic. Otaku fetishism sign post-digital grenade warehouse physical free-market pre-A.I. neural. Tube car free-market systemic city 8-bit meta-crypto-sub-orbital. Military-grade futurity shrine range-rover DIY youtube alcohol realism systemic. Modem into construct spook office pen Tokyo rain. Dead footage wristwatch corporation-space neon skyscraper silent assault order-flow free-market. Rifle grenade systemic stimulate concrete beef noodles motion vehicle courier free-market face forwards wonton soup.</p>
					</div><!-- Post Description -->

				</div><!-- END : Featured -->


				<!-- Content Sidebar -->
				<div class="content-sidebar columns small-12 medium-4 large-3">
					<div class="section-label h5 text-neutral">Categories</div>
						<a class="category-icon podcast" href="">
							<div class="cat-i-title h3">Lazaro Podcast</div>
							<div class="cat-i-label h5">Archive <span class="count">2</span></div>
						</a>
						<a class="category-icon featurette" href="">
							<div class="cat-i-title h3">Industry Featurette</div>
							<div class="cat-i-label h5">Showcase <span class="count">8</span></div>
						</a>
						<a class="category-icon work" href="">
							<div class="cat-i-title h3">Case Studies</div>
							<div class="cat-i-label h5">Portfolio <span class="count">1</span></div>
						</a>
				</div><!-- END : Content Section -->


			</div>
		</div>
	</section> <!-- END : Featured Section -->

	

	<!-- Posts Section -->
	<section class="posts-section fill-dark">
		<div class="container">
			<div class="row">

				<!-- Posts -->
				<div class="posts columns small-12 medium-8 large-7 large-offset-1">
					<div class="section-label h5 text-neutral">Articles</div>

					<article>
						<div class="row">
							<div class="columns small-12 medium-4">
								<!-- Post Featured Image -->
								<div class="post-summary-image thumbnail">
									<img src="/img/thumb-ep-1.png">
								</div><!-- END : Post Featured Image -->
							</div>
							<div class="columns small-12 medium-8">
								<!-- Post Title -->
								<div class="post-title">
									<a href="#">
										<div class="h3">6 Steps to Tame a wide Marketing Funnel without a Large Sales Team - Part 1</div>
									</a>
								</div><!-- END : Post Title -->
								<!-- Post Title Meta -->
								<div class="post-title-meta">
									<div class="h5 inline inline">[podcast-icon]</div>
									<div class="h5 inline inline">17 September 2017</div>
								</div><!-- END : Post Title Meta -->
							</div>
						</div>
					</article>

				</div><!-- END : Posts -->

				<!-- Content Sidebar -->
				<div class="content-sidebar columns small-12 medium-4 large-3">
					<div class="section-label h5 text-neutral">Content Sidebar</div>
				</div><!-- END : Content Section -->

			</div>
		</div>
	</section> <!-- END : Posts Section -->

</div>

